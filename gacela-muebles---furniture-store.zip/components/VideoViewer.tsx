import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

interface VideoViewerProps {
  videoUrl: string | null;
  onClose: () => void;
}

const VideoViewer: React.FC<VideoViewerProps> = ({ videoUrl, onClose }) => {
  return (
    <AnimatePresence>
      {videoUrl && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[500] bg-black/80 flex items-center justify-center p-4"
          onClick={onClose} // Cierra al hacer clic en el overlay
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="relative max-w-4xl w-full aspect-video bg-black rounded-lg shadow-2xl overflow-hidden" // aspect-video para mantener relación 16:9
            onClick={(e) => e.stopPropagation()} // Evita que se cierre al hacer clic en el video
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 bg-white/70 backdrop-blur-sm rounded-full shadow-md text-brand-text hover:bg-white transition-colors z-10"
              aria-label="Cerrar video"
            >
              <X size={24} />
            </button>
            <video
              src={videoUrl}
              controls
              autoPlay // Reproducción automática al abrir
              className="w-full h-full object-contain"
            >
              Tu navegador no soporta la etiqueta de video.
            </video>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default VideoViewer;