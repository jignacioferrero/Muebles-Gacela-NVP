
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

interface ImageViewerProps {
  imageUrl: string | null;
  onClose: () => void;
}

const ImageViewer: React.FC<ImageViewerProps> = ({ imageUrl, onClose }) => {
  return (
    <AnimatePresence>
      {imageUrl && ( // Solo renderiza si imageUrl existe, permitiendo a AnimatePresence manejar la animación de salida
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[500] bg-black/80 flex items-center justify-center p-4"
          onClick={onClose} // Cierra al hacer clic en el overlay
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="relative max-w-4xl max-h-[90vh] w-full h-auto bg-white rounded-lg shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()} // Evita que se cierre al hacer clic en la imagen
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 bg-white/70 backdrop-blur-sm rounded-full shadow-md text-brand-text hover:bg-white transition-colors z-10"
              aria-label="Cerrar imagen"
            >
              <X size={24} />
            </button>
            <img
              src={imageUrl}
              alt="Imagen ampliada del herraje"
              className="w-full h-full object-contain"
            />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ImageViewer;
